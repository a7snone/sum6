<?php $__env->startSection('content'); ?>

<?php echo Form::open(['action' => 'App\Http\Controllers\jdController@store', 'method' => 'POST']); ?>

    
    <div class='form-group'>
        <?php echo e(Form::label('title','المسمى الوظيفي')); ?>

        <?php echo e(Form::text('title','',['class' => 'form-control jd-body','placeholder' => ''])); ?>

    </div>
    
    <div class='form-group'>
        <?php echo e(Form::label('title','المؤهلات العلمية')); ?>

        <select name='degree' class="jdSelect form-control">
            <option>ابتدائي</option>
            <option>متوسط</option>
            <option>ثانوي</option>
            <option>دبلوم</option>
            <option>بكالوريوس</option>
            <option>ماجستير</option>
            <option>دكتوراه</option>
        </select>
    </div>
        <!-- <?php echo e(Form::select('degree_',[
            'ابتدائي' => 'ابتدائي',
            'متوسط' => 'متوسط',
            'ثانوي' => 'ثانوي',
            'دبلوم' => 'دبلوم',
            'بكالوريوس' => 'بكالوريوس',
            'ماجستير' => 'ماجستير',
            'دكتوراه' => 'دكتوراه',
            ],['class' => 'form-control select-degree','placeholder' => ''])); ?> -->
    
    <div class='form-group'>
        <?php echo e(Form::label('title','الخبرة العملية')); ?>

        <?php echo e(Form::textarea('experiences','',['class' => 'form-control jd-body','placeholder' => ''])); ?>

    </div >
    
    <!-- <div class='form-group'>
        <?php echo e(Form::label('title','الارتباط التنظيمي')); ?>

        <?php echo e(Form::textarea('link','',['class' => 'form-control','placeholder' => ''])); ?>

    </div >
     -->
    <div class='form-group'>
        <?php echo e(Form::label('title','المعارف والقدرات والمهارات المطلوبة')); ?>

        <?php echo e(Form::textarea('knowledge','',['class' => 'form-control jd-body','placeholder' => ''])); ?>

    </div >
    
    <div class='form-group'>
        <?php echo e(Form::label('title','المهام والمسئوليات')); ?>

        <?php echo e(Form::textarea('responsibilities','',['class' => 'form-control jd-body','placeholder' => ''])); ?>

    </div >

    <div class='form-group'>
        <?php echo e(Form::label('title','الوصف حسب الجهة')); ?>

        <?php echo e(Form::textarea('muD','',['class' => 'form-control jd-body','placeholder' => ''])); ?>

    </div >
  
    <?php echo e(Form::submit('حفظ',['class' => ' btn btn-primary'])); ?>


<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac5k/www/mu/resources/views/pages/jd/create.blade.php ENDPATH**/ ?>