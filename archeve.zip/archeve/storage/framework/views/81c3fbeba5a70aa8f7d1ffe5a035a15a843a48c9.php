<?php $__env->startSection('content'); ?>

<!-- <div class="content"> -->
<br/>
<?php echo e(Form::label('title','اختر المسمى الوظيفي')); ?>

    <select class="jdSelect form-control" onchange="{ location.href = '/jd/'+options[selectedIndex].id;}">
        <option id='0' disabled selected><?php echo e($jd->name); ?></option>
        <?php if(count($jds)): ?>
            <?php $__currentLoopData = $jds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jdloop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option id=<?php echo e($jdloop->id); ?> ><?php echo e($jdloop->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
<br/>
<br/>

<p class="jdTitle"><?php echo e($jd->name); ?></p>
<br/>
<div >
        <p class="jd-title">المؤهلات العلمية</p>
        <p class="jd-body"><?php echo e($jd -> degree); ?></p>
    </div>
    <div >
        <p class="jd-title">الخبرة العملية</p>
        <p class="jd-body"><?php echo e($jd -> experiences); ?></p>
    </div>
    <!-- <div >
        <p>الارتباط التنظيمي</p>
        <p class="mohrD"><?php echo e($jd -> link); ?></p>
    </div> -->
    <div >
        <p class="jd-title">المعارف والقدرات والمهارات المطلوبة</p>
        <p class="jd-body"><?php echo e($jd -> knowledge); ?></p>
    </div>
    <div >
        <p class="jd-title">المهام والمسئوليات</p>
        <p class="jd-body"><?php echo e($jd -> responsibilities); ?></p>
    </div>
    
    <div >
        <p class="jd-title">الوصف حسب الجهة:  :</p>
        <p class="jd-body"><?php echo e($jd -> muD); ?></p>
    </div>

<!-- </div> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/programmer/www/application/resources/views/pages/jd/show.blade.php ENDPATH**/ ?>