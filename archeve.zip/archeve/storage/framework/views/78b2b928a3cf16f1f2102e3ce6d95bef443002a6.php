<?php $__env->startSection('content'); ?>

<!-- <div class="content"> -->
<br/>
<?php echo e(Form::label('title','اختر المسمى الوظيفي')); ?>

    <select class="jdSelect form-control" onchange="{ location.href = '/jd/'+options[selectedIndex].id;}">
        <option id='0' disabled selected>الرجاء الاختيار</option>
        <?php if(count($jds)): ?>
            <?php $__currentLoopData = $jds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option id=<?php echo e($jd->id); ?> ><?php echo e($jd->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
<br/>
<br/>

<!-- </div> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/programmer/www/application/resources/views/pages/jd/index.blade.php ENDPATH**/ ?>