<?php $__env->startSection('content'); ?>
<div class="content">
    مرحبا بكم من services
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/programmer/www/application/resources/views/pages/services.blade.php ENDPATH**/ ?>