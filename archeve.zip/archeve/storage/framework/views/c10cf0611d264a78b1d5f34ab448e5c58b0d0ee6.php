<?php $__env->startSection('content'); ?>

<?php

$mohrDescribe = 'لم يتم الاختيار...';
$muDescribe = 'لم يتم الاختيار...';

?>

<div class="content">
<br/>
اختر الوظيفة:
    <select class="jt" onchange="{ location.href = '/jd/'+options[selectedIndex].id;}">
        <option value='' disabled selected>الرجاء الاختيار</option>
        <option id='1' >سكرتير</option>
        <option id='2' >مراسل</option>
        <option id='3' >مبرمج</option>
        <option id='84' >مصور</option>
        <option id='5' >محلل نظم</option>
        <option id='6' >مدخل بيانات</option>
    </select>
<br/>

<br/>
    <div class="mohrD">
        <h5>الوصف حسب وزارة الموارد البشرية:</h5>
        <p><?php echo e($mohrDescribe); ?></p>
    </div>
    <div class="mohrD">
        <h5>الوصف حسب الجهة:  :</h5>
        <p><?php echo e($muDescribe); ?></p>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/programmer/www/application/resources/views/pages/jd.blade.php ENDPATH**/ ?>