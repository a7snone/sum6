<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use db;

class PageController extends Controller
{
    public function index(){
        return view('pages.index');
    }

    // public function services(){
    //     return view('pages.services');
    // }

    public function jd(){
        // $days = 'Saterday';

        
        return view('pages.jd') ;//->with('days',$days);
    }

    public function search(){
        return view('pages.search');
    }
}