<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Jd;

class jdController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $jds = Jd::all();
        return view('pages.jd.index') -> with('jds',$jds);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('pages.jd.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'title' => 'required',
        ]);

        $jd = new Jd;
        $jd->name = $request->input('title');
        $jd->degree = $request->input('degree');
        $jd->experiences = $request->input('experiences');
        $jd->link = '';//$request->input('link');
        $jd->knowledge = $request->input('knowledge');
        $jd->responsibilities = $request->input('responsibilities');
        $jd->muD = $request->input('muD');
        $jd->save();
        
        return redirect('/jd/'.$jd->id)->with('success','تم الحفظ');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $jds= Jd::all();
        $jd = Jd::find($id);
        
        $array=[
            'jds' => $jds,
            'jd'  => $jd,
        ];

        //return view('pages.jd.show') -> with('jd',$jd) ;
        return view('pages.jd.show') -> with($array) ;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
