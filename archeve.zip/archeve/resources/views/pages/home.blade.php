@extends('layouts.app')

@section('content')
<h1>Hi from home :)</h1>
@endsection