@extends('layouts.app')

@section('content')

{!! Form::open(['action' => 'App\Http\Controllers\jdController@store', 'method' => 'POST']) !!}
    
    <div class='form-group'>
        {{Form::label('title','المسمى الوظيفي')}}
        {{Form::text('title','',['class' => 'form-control jd-body','placeholder' => ''])}}
    </div>
    
    <div class='form-group'>
        {{Form::label('title','المؤهلات العلمية')}}
        <select name='degree' class="jdSelect form-control">
            <option>ابتدائي</option>
            <option>متوسط</option>
            <option>ثانوي</option>
            <option>دبلوم</option>
            <option>بكالوريوس</option>
            <option>ماجستير</option>
            <option>دكتوراه</option>
        </select>
    </div>
        <!-- {{Form::select('degree_',[
            'ابتدائي' => 'ابتدائي',
            'متوسط' => 'متوسط',
            'ثانوي' => 'ثانوي',
            'دبلوم' => 'دبلوم',
            'بكالوريوس' => 'بكالوريوس',
            'ماجستير' => 'ماجستير',
            'دكتوراه' => 'دكتوراه',
            ],['class' => 'form-control select-degree','placeholder' => ''])}} -->
    
    <div class='form-group'>
        {{Form::label('title','الخبرة العملية')}}
        {{Form::textarea('experiences','',['class' => 'form-control jd-body','placeholder' => ''])}}
    </div >
    
    <!-- <div class='form-group'>
        {{Form::label('title','الارتباط التنظيمي')}}
        {{Form::textarea('link','',['class' => 'form-control','placeholder' => ''])}}
    </div >
     -->
    <div class='form-group'>
        {{Form::label('title','المعارف والقدرات والمهارات المطلوبة')}}
        {{Form::textarea('knowledge','',['class' => 'form-control jd-body','placeholder' => ''])}}
    </div >
    
    <div class='form-group'>
        {{Form::label('title','المهام والمسئوليات')}}
        {{Form::textarea('responsibilities','',['class' => 'form-control jd-body','placeholder' => ''])}}
    </div >

    <div class='form-group'>
        {{Form::label('title','الوصف حسب الجهة')}}
        {{Form::textarea('muD','',['class' => 'form-control jd-body','placeholder' => ''])}}
    </div >
  
    {{Form::submit('حفظ',['class' => ' btn btn-primary'])}}

{!! Form::close() !!}

@endsection