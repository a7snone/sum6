@extends('layouts.app')

@section('content')

<!-- <div class="content"> -->
<br/>
{{Form::label('title','اختر المسمى الوظيفي')}}
    <select class="jdSelect form-control" onchange="{ location.href = '/jd/'+options[selectedIndex].id;}">
        <option id='0' disabled selected>{{ $jd->name }}</option>
        @if(count($jds))
            @foreach($jds as $jdloop)
                <option id={{ $jdloop->id }} >{{ $jdloop->name }}</option>
            @endforeach
        @endif
    </select>
<br/>
<br/>

<p class="jdTitle">{{ $jd->name }}</p>
<br/>
<div >
        <p class="jd-title">المؤهلات العلمية</p>
        <p class="jd-body">{{ $jd -> degree }}</p>
    </div>
    <div >
        <p class="jd-title">الخبرة العملية</p>
        <p class="jd-body">{{ $jd -> experiences }}</p>
    </div>
    <!-- <div >
        <p>الارتباط التنظيمي</p>
        <p class="mohrD">{{ $jd -> link }}</p>
    </div> -->
    <div >
        <p class="jd-title">المعارف والقدرات والمهارات المطلوبة</p>
        <p class="jd-body">{{ $jd -> knowledge }}</p>
    </div>
    <div >
        <p class="jd-title">المهام والمسئوليات</p>
        <p class="jd-body">{{ $jd -> responsibilities }}</p>
    </div>
    
    <div >
        <p class="jd-title">الوصف حسب الجهة:  :</p>
        <p class="jd-body">{{ $jd -> muD }}</p>
    </div>

<!-- </div> -->
@endsection