@extends('layouts.app')

@section('content')

<!-- <div class="content"> -->
<br/>
{{Form::label('title','اختر المسمى الوظيفي')}}
    <select class="jdSelect form-control" onchange="{ location.href = '/jd/'+options[selectedIndex].id;}">
        <option id='0' disabled selected>الرجاء الاختيار</option>
        @if(count($jds))
            @foreach($jds as $jd)
                <option id={{ $jd->id }} >{{ $jd->name }}</option>
            @endforeach
        @endif
    </select>
<br/>
<br/>

<!-- </div> -->
@endsection