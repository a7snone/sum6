@extends('layouts.app')

@section('content')
<div class="content">
    مرحبا بكم من index
</div>
@endsection