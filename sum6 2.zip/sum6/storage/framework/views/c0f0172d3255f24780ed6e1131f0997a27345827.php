<img src="<?php echo e(URL::asset('/images/header.jpg')); ?>" alt="profile Pic" height="" width="100%"
    onclick="window.open('/')">
<p class="headerTitle" style="padding-top: 50px;
    color: #2ad841;
    font-weight: bold;
    text-align: center;
    font-size: 20px;">
    الاشتراك في خدمة النقل
</p>
<?php /**PATH /Users/mac5k/www/qu/sum6/resources/views/layouts/partials/header.blade.php ENDPATH**/ ?>