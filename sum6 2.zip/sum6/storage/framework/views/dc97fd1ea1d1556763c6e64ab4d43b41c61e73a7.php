<!-- <?php $__env->startSection('pageTitle', 'التسجيل في خدمة النقل'); ?> -->

<?php $__env->startSection('content'); ?>


<div class="transferingDetails">
    <p style="color: #278b27;">تم التسجيل بنجاح.</p>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac5k/www/qu/sum6/resources/views/pages/done.blade.php ENDPATH**/ ?>