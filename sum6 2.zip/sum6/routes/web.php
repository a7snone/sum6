<?php

use Illuminate\Support\Facades\Route;
//use GoogleController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//  Route::get('/', function () {
//      return view('welcome');
//  });

//Route::resource('/', GoogleController::class);
Route::resource('/', StudentController::class);
Route::post('/register', 'MainController@register');
Route::get('/done','MainController@showMessage');
