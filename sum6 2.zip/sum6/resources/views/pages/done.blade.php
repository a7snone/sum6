@extends('layouts.master')

<!-- @section('pageTitle', 'التسجيل في خدمة النقل') -->

@section('content')


<div class="transferingDetails">
    <p style="color: #278b27;">تم التسجيل بنجاح.</p>
</div>


@endsection
