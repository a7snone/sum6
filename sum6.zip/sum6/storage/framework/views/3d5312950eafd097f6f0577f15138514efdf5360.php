<?php $__env->startSection('pageTitle', 'Home'); ?>

<?php $__env->startSection('content'); ?>
<div class="jumbotron">
    <h1 class="display-4">عن النادي الصيفي - 6</h1>
    <p class="lead">كلام عن النادي الصيفي - 5 </p>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac5k/www/qu/sum6/resources/views/welcome.blade.php ENDPATH**/ ?>