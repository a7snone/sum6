<img src="<?php echo e(URL::asset('/images/header.jpg')); ?>" alt="profile Pic" height="" width="100%">
<p class="headerTitle">
    الاشتراك في خدمة النقل
</p>
<?php /**PATH /Users/mac5k/www/qu/sum6/resources/views/layouts/partials/header.blade.php ENDPATH**/ ?>